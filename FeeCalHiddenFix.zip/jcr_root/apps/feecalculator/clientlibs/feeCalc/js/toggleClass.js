//$(window).load(function() {
$(function() {

//---------------Below code is for Select Dropdown requirement -----------------//

    $("select[id='guideContainer-rootPanel-panel-panel_185352355_copy-guidedropdownlist_82___widget']").addClass('hiddenDropDownClass');

    $('.hiddenDropDownClass').click(function(event) {
	event.preventDefault();
    $('.dropDownList').addClass('dropDownClass');

        $('select').toggleClass('active');
       // $(".dropDownClass").toggleClass('upDown');


    });

console.log("form-load");
//$("div[data-guide-parent-id='guideContainer-rootPanel-panel-parentWhatFeeCalcPanel__']").removeClass('active');
//$("div[id='guideContainer-rootPanel-panel-parentHowDoesItWorkPanel-howitworkspanel___guide-item']").removeClass('active');
    $("div[id='guideContainer-rootPanel-panel-parentHowDoesItWorkPanel___guide-item-container']").css({'margin-top':'-1px'});



$(".accordion-navigators").css("background-color", "#f9f9f9");

   /* $('.submit button').click(function() {

    	$('.dropDownList').addClass('dropDownClass');
        console.log("inside submit");
        $('select').click(function(event) {
			console.log("inside select");
            event.preventDefault();
            //var selectDrp = $(this).parent();
			var selectDrp = $(this);
            console.log(selectDrp);
            selectDrp.toggleClass('active');
        });

    });*/

    $("div[id='guideContainer-rootPanel-panel_470662117_copy-yourFeeTextPanel-guidetextdraw_231131___guide-item']").css({"height":"54px"});
    $("div[id='guideContainer-rootPanel-panel-parentWhatFeeCalcPanel___layoutContainer']").css({"margin-top":"18px"});

    $('#nav-header-item1').hover(function(){
        console.log("inside hover");
    $('#nav-header-item1').toggleClass('navHoverClass');
	});

    $('#nav-header-item2').hover(function(){
        console.log("inside hover");
    $('#nav-header-item2').toggleClass('navHoverClass');
	});

    $('#nav-header-item3').hover(function(){
        console.log("inside hover");
    $('#nav-header-item3').toggleClass('navHoverClass');
	});

    $('#nav-header-item4').hover(function(){
        console.log("inside hover");
    $('#nav-header-item4').toggleClass('navHoverClass');
	});

    $('#nav-header-item5').hover(function(){
        console.log("inside hover");
    $('#nav-header-item5').toggleClass('navHoverClass');
	});

   /* $('.hiddenDropDownClass').click(function() {
        console.log("inside click");
        $('.hiddenDropDownClass option').addClass('dropDownOption');
    });*/

    //-------------------- Adding margin bottom to age panel ------------------------//
    //$("div[id='guideContainer-rootPanel-conditionPanel___guide-item-container']").css({"margin-bottom","16px"});

});